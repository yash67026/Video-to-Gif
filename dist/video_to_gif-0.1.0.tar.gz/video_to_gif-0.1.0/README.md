# Video to GIF Converter

A simple Python tool to convert short videos to GIFs.

## 📌 Installation
```bash
pip install video-to-gif
